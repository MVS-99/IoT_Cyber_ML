# Import necessary libraries
from sklearn.ensemble import RandomForestClassifier
from sklearn.neighbors import LocalOutlierFactor

import matplotlib.pyplot as plt
import seaborn as sns
import pandas as pd

def select_features(df, target_column, exclude_column):
    """
    Select features based on their importance for predicting whether an attack occurs.
    """
    # Ensure target column is numeric
    if df[target_column].dtype == 'object':
        df[target_column] = df[target_column].astype('category').cat.codes

    # Fit a random forest classifier to the data
    clf = RandomForestClassifier(n_estimators=100, random_state=42)
    clf.fit(df.drop(target_column, axis=1), df[target_column])

    # Get feature importances
    importances = clf.feature_importances_

    # Create a DataFrame of features and importances
    features_importances = pd.DataFrame({'Feature': df.drop([target_column,exclude_column], axis=1).columns, 'Importance': importances})

    # Sort the DataFrame by importance in descending order and select top 22 features
    features_importances = features_importances.sort_values(by='Importance', ascending=False).head(22)
    if(target_column == "Attack_label"):
        # Plot the feature importances
        plt.figure(figsize=(10, 6))
        sns.barplot(x='Importance', y='Feature', data=features_importances)
        plt.xscale('log')
        plt.title('Feature Importances for Attack Detection')
        plt.show()
    else:
        # Plot the feature importances
        plt.figure(figsize=(10, 6))
        sns.barplot(x='Importance', y='Feature', data=features_importances)
        plt.xscale('log')
        plt.title('Feature Importances for Attack Type Classification')
        plt.show()

    return features_importances

def detect_and_remove_outliers(df, n_neighbors, contamination):
    """
    Use the Local Outlier Factor method to detect and remove outliers from df.
    """
    # Use Local Outlier Factor to identify outliers
    lof = LocalOutlierFactor(n_neighbors=n_neighbors, contamination=contamination)
    y_pred = lof.fit_predict(df)

    # Filter out the outliers
    mask = y_pred != -1
    df = df[mask]

    return df